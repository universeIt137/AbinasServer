const dpsQueryKeys = ["memberID", "dpsNo", "approveStatus"];
const fdrQueryKeys = ["status", "fdrType", "fdrNo"];
module.exports = {
  dpsQueryKeys,
  fdrQueryKeys,
};
