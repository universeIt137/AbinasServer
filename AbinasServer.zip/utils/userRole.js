let USER_ROLE = {
  ADMIN: "admin",
  USER: "user",
  SUPER_ADMIN: "super_admin",
};
module.exports = USER_ROLE;
